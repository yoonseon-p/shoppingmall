package db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConn {
	private DbConn() {}
	public static Connection getConnection() throws Exception {
		String url = "jdbc:mysql://localhost:3306/webmarketdb";
		String user = "admin";
		String psw = "admin1234";
		
		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection(url,user,psw);
	}
}
