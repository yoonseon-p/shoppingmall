package log4j;

import org.apache.log4j.Logger;

public class LogTest {
	private static  Logger logger = Logger.getLogger(LogTest.class);
	
	public static void main(String[] args) {
		logger.debug("### 디버깅시 사용");
	}
}
