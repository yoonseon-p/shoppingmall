package spring.lecture.basic;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MemberController {
	@Autowired
	private MemberService service;
	
	@RequestMapping(value = "/member", method = RequestMethod.GET)
	public ModelAndView create() {
		return new ModelAndView("member/member");
	}
	
	@RequestMapping(value = "/member", method = RequestMethod.POST)
	public ModelAndView create(@RequestParam Map<String, Object> map) {
		ModelAndView mav = new ModelAndView();
		boolean isCreated = service.create(map);
		if(isCreated) {
			System.out.println("success");
			mav.setViewName("redirect:/member");
		}
		else {
			System.out.println("faile");
			mav.setViewName("redirect:/member");
		}
		return mav;
	}
	
	@RequestMapping(value = "/detail", method = RequestMethod.GET)
	public ModelAndView detail(@RequestParam Map<String,Object> map) {
		ModelAndView mav = new ModelAndView();
		Map<String, Object> detailMap = service.selectDetail(map);
		mav.addObject("data",detailMap);
		mav.setViewName("/member/detail");
		return mav;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public ModelAndView update(@RequestParam Map<String,Object> map) {
		ModelAndView mav = new ModelAndView();
		Map<String, Object> detailMap = service.selectDetail(map);
		mav.addObject("data",detailMap);
		mav.setViewName("/member/update");
		return mav;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView updatePost(@RequestParam Map<String,Object> map) {
		ModelAndView mav = new ModelAndView();
		Map<String, Object> detailMap = service.selectDetail(map);
		if(detailMap != null && detailMap.get("passwd").equals(map.get("passwd"))) {
			service.update(map);
//			mav.setViewName("redirect:/update?id="+map.get("id"));
//			mav.setViewName("/member/update");
			mav = this.update(map);
			mav.addObject("message","변경되었습니다.");
		}else {
			mav = this.update(map);
			mav.addObject("message","패스워드가<br> 틀렸습니다.");
		}
		return mav;
	}
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(){
		ModelAndView mav = new ModelAndView("/member/list");
		mav.addObject("memberlists",service.list());
		return mav;
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public ModelAndView delete(@RequestParam Map<String,Object> map) {
		ModelAndView mav = new ModelAndView();
		boolean isSuccessDelete = (service.delete(map) == 1);
		if(isSuccessDelete) {
			mav.setViewName("redirect:/list");
		}else {
			mav = this.detail(map);
		}
		return mav;
	}
}
